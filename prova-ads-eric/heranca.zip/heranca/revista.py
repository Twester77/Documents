from item_acervo import ItemAcervo

class Revista(ItemAcervo):
    def __init__(self, titulo, ano, edicao):
        super().__init__(titulo, ano)
        self.edicao = edicao
        