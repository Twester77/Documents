class ItemAcervo:
    def __init__(self, titulo, ano):
        self.titulo = titulo
        self.ano = ano

    def prazo_de_emprestimo(self):
        return 0